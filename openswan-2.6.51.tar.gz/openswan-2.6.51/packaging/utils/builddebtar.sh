#!/bin/sh

export BUILDENV=debian; make tarpkg
